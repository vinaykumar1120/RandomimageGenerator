const imageGallery = document.getElementById('imageGallery');
const loadMoreButton = document.getElementById('loadMore');


function getRandomImageUrl() {
    const randomId = Math.floor(Math.random() * 1000);
    console.log(randomId)
    return `https://picsum.photos/300?random=${randomId}`;

}

function loadImages(count) {
    for (let i = 0; i < count; i++) {
        const img = document.createElement('img');
        img.src = getRandomImageUrl();
        img.alt = 'Random Image';
        imageGallery.appendChild(img);
    }
}

window.onload = () => {
    loadImages(6);
};

loadMoreButton.addEventListener('click', () => {
    loadImages(10);
});